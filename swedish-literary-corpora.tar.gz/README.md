README

# Swedish Literary Corpus

literary-corpus-swe.tar.gz contains four novels by four distinct Swedish authors. 

- August Strindberg - The Red Room (1879)
- Hjalmar Söderbergh - The Serious Game (1912)
- Karin Boye - Kallocain (1940)
- Birger Sjöberg - The Quartet That Split Up, part I (1924)

For each novel a number of chapters have been selected and annotated, with the following naming convention:
  AUTHOR_CHAPTERNUMBER.txt

For each dialogue in the text, each turn has been annotated with the following information and structure:

<Speaker--Addressee> <Speaker_type--Addressee_type><Comment>

The scope of the tag is untill the start of the line, or when another tag is encountered. Only lines where there is a certain and distinct speaker and addressee has been annotated, e.g. characters talking to themselves has not been annotated, furthermore situations such as "bla bla, one of the ladies said" have not been annotated due to the uncertainty of the speaker. 

Speaker and addressee types are coded in the following manner:

EXP - Explicit
ANA - Anaphoric pronoun
DESC - Definite description
IMP - Implicit

